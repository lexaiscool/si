function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(0, 0, 50);

  // Draw stars
  drawStars();

  // Draw moon
  drawMoon();

  // Draw cat
  drawCat();
}

function drawStars() {
  noStroke();
  fill(255, 255, 0);
  for (let i = 0; i < 100; i++) {
   let x = random(width);
  let y = random(height);
    let size = random(1, 2);
    polygon(x, y, 5, size);
  }
}

function polygon(x, y, sides, radius) {
  let angle = TWO_PI / sides;
  beginShape();
  for (let a = 0; a < TWO_PI; a += angle) {
    let sx = x + cos(a) * radius;
    let sy = y + sin(a) * radius;
    vertex(sx, sy);
  }
  endShape(CLOSE);
}

function drawMoon() {
  fill(255, 255, 153);
  ellipse(100, 100, 80, 80);
  fill(0, 0, 50);
  ellipse(120, 80, 80, 80);
}

function drawCat() {
  // Body
  fill(181, 103, 35);
  stroke(85, 39, 14);
  strokeWeight(2);
  ellipse(250, 350, 80, 80);

  // Ears
  noStroke();
  fill(226, 139, 42);
  triangle(218, 320, 230, 290, 250, 310);
  triangle(282, 320, 270, 290, 250, 310);

  // Face
  fill(226, 139, 42);
  ellipse(250, 340, 50, 40);

  // Eyes
  fill(255);
  ellipse(232, 340, 12, 20);
  ellipse(268, 340, 12, 20);

  // Pupils
  fill(0);
  ellipse(228, 340, 6, 10);
  ellipse(264, 340, 6, 10);

  // Nose
  fill(102, 64, 29);
  ellipse(250, 350, 20, 16);

  // Mouth
  fill(255, 190, 191);
  stroke(231, 0, 18);
  strokeWeight(3);
  arc(250, 370, 30, 20, 0, PI);

  // Whiskers
  stroke(0);
  strokeWeight(1);
  line(232, 355, 205, 355);
  line(232, 360, 205, 365);
  line(232, 365, 205, 375);
  line(268, 355, 295, 355);
  line(268, 360, 295, 365);
  line(268, 365, 295, 375);
}

